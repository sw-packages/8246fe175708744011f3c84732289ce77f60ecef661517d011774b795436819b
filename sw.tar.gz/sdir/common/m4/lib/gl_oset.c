#include <config.h>
#define GL_OSET_INLINE inline
//_GL_EXTERN_INLINE
#include "gl_oset.h"
